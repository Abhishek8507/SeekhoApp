package com.example.seekhoapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: AnimeViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AnimeAdapter
    private lateinit var progressBar: ProgressBar
    private lateinit var refreshButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView = findViewById(R.id.recyclerView)
        progressBar = findViewById(R.id.progressBar)
        refreshButton = findViewById(R.id.refreshButton)

        // ViewModel setup
        viewModel = ViewModelProvider(this).get(AnimeViewModel::class.java)
        recyclerView.layoutManager = LinearLayoutManager(this)


        adapter = AnimeAdapter(emptyList()) { animeId ->
            val intent = Intent(this, AnimeDetailActivity::class.java).apply {
                putExtra("anime_id", animeId)  // Ensure the anime ID is pased correctly
            }
            startActivity(intent)
        }
        recyclerView.adapter = adapter

        // Start observing the anime list
        observeAnimeList()
        fetchAnimeList()
        refreshButton.setOnClickListener {
            fetchAnimeList()
        }
    }

    private fun observeAnimeList() {
        viewModel.animeList.observe(this) { animeList ->
            progressBar.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
            adapter.updateAnimeList(animeList)
        }
    }

    private fun fetchAnimeList() {
        progressBar.visibility = View.VISIBLE
        recyclerView.visibility = View.GONE

        viewModel.fetchAnimeList()
    }
}

