package com.example.seekhoapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.seekhoapp.databinding.ItemAnimeBinding

class AnimeAdapter(private var animeList: List<AnimeItem>, private val onItemClick: (Int) -> Unit) :
    RecyclerView.Adapter<AnimeAdapter.AnimeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AnimeViewHolder {
        val binding = ItemAnimeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AnimeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AnimeViewHolder, position: Int) {
        holder.bind(animeList[position])
    }

    override fun getItemCount(): Int = animeList.size

    inner class AnimeViewHolder(private val binding: ItemAnimeBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(anime: AnimeItem) {
            binding.animeTitle.text = anime.title
            binding.animeEpisodes.text = "Episodes: ${anime.episodes ?: "N/A"}"
            binding.animeScore.text = "Score: ${anime.score ?: "N/A"}"

            Glide.with(binding.animeImage.context)
                .load(anime.images.jpg.image_url)
                .into(binding.animeImage)

            binding.root.setOnClickListener {
                onItemClick(anime.mal_id)
            }
        }
    }

    fun updateAnimeList(newList: List<AnimeItem>) {
        animeList = newList
        notifyDataSetChanged()
    }
}
