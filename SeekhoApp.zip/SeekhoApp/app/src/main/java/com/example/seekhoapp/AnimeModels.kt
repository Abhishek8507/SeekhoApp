package com.example.seekhoapp

data class AnimeResponse(val data: List<AnimeItem>)

data class AnimeItem(
    val mal_id: Int,  // Ensure this field exists
    val title: String,
    val episodes: Int?,
    val score: Double?,
    val images: AnimeImages
)


data class AnimeImages(val jpg: AnimeImageUrl)
data class AnimeImageUrl(val image_url: String)

data class AnimeDetailResponse(val data: AnimeDetail)

data class AnimeDetail(
    val title: String,
    val synopsis: String?,
    val genres: List<Genre>,
    val episodes: Int?,
    val score: Double?,
    val trailer: Trailer?,
    val images: AnimeImages
)

data class Genre(val name: String)
data class Trailer(val url: String?)
