package com.example.seekhoapp

import android.util.Log
import androidx.lifecycle.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AnimeViewModel : ViewModel() {

    private val _animeList = MutableLiveData<List<AnimeItem>>()
    val animeList: LiveData<List<AnimeItem>> = _animeList

    private val _animeDetails = MutableLiveData<AnimeDetail?>()
    val animeDetails: LiveData<AnimeDetail?> = _animeDetails

    private val apiService = ApiClient.instance.create(AnimeService::class.java)

    fun fetchAnimeList() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = apiService.getTopAnime()
                withContext(Dispatchers.Main) {
                    _animeList.value = response.data
                }
            } catch (e: Exception) {
                _animeList.postValue(emptyList()) // Handle failure
            }
        }
    }

    fun fetchAnimeDetails(animeId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = apiService.getAnimeDetails(animeId)
                Log.d("API_RESPONSE", response.toString())
                withContext(Dispatchers.Main) {
                    _animeDetails.value = response.data
                }
            } catch (e: Exception) {
                Log.e("API_ERROR", "Error fetching anime details", e)
                _animeDetails.postValue(null)
            }
        }
    }
}
