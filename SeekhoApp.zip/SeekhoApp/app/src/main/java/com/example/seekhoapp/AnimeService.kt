package com.example.seekhoapp

import retrofit2.http.GET
import retrofit2.http.Path

interface AnimeService {
    @GET("top/anime")
    suspend fun getTopAnime(): AnimeResponse  // ✅ Ensure this is correctly mapped

    @GET("anime/{id}")
    suspend fun getAnimeDetails(@Path("id") animeId: Int): AnimeDetailResponse  // ✅ Ensure `id` is used correctly
}

