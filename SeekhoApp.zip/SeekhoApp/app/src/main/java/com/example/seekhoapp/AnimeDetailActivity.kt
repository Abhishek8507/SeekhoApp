package com.example.seekhoapp

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide

class AnimeDetailActivity : AppCompatActivity() {
    private lateinit var viewModel: AnimeViewModel
    private lateinit var titleText: TextView
    private lateinit var synopsisText: TextView
    private lateinit var genresText: TextView
    private lateinit var episodesText: TextView
    private lateinit var ratingText: TextView
    private lateinit var posterImage: ImageView
    private lateinit var webViewTrailer: WebView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_anime_detail)
        titleText = findViewById(R.id.anime_title)
        synopsisText = findViewById(R.id.anime_synopsis)
        genresText = findViewById(R.id.anime_genres)
        episodesText = findViewById(R.id.anime_episodes)
        ratingText = findViewById(R.id.anime_rating)
        posterImage = findViewById(R.id.anime_poster)
        webViewTrailer = findViewById(R.id.webViewTrailer)
        progressBar = findViewById(R.id.progressBar)
        webViewTrailer.settings.javaScriptEnabled = true
        webViewTrailer.settings.loadWithOverviewMode = true
        webViewTrailer.settings.useWideViewPort = true
        webViewTrailer.settings.mediaPlaybackRequiresUserGesture = false
        viewModel = ViewModelProvider(this).get(AnimeViewModel::class.java)

        // Get anime ID
        val animeId = intent.getIntExtra("anime_id", -1)
        if (animeId != -1) {
            viewModel.fetchAnimeDetails(animeId)
            observeAnimeDetails()
        } else {
            Toast.makeText(this, "Invalid Anime ID", Toast.LENGTH_SHORT).show()
        }
    }

    private fun observeAnimeDetails() {
        viewModel.animeDetails.observe(this) { anime ->
            if (anime != null) {
                titleText.text = anime.title
                synopsisText.text = anime.synopsis ?: "No Synopsis Available"
                genresText.text = "Genres: ${anime.genres.joinToString { it.name }}"
                episodesText.text = "Episodes: ${anime.episodes ?: "N/A"}"
                ratingText.text = "Rating: ${anime.score ?: "N/A"}"

                // Load poster image
                Glide.with(this)
                    .load(anime.images.jpg.image_url)
                    .into(posterImage)
                val youtubeId = extractYouTubeId(anime.trailer?.url)
                if (youtubeId != null) {
                    playTrailer(youtubeId)
                } else {
                    showPoster()
                }
            } else {
                Toast.makeText(this, "Failed to load details", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Function to extract YouTube iD
    private fun extractYouTubeId(trailerUrl: String?): String? {
        if (trailerUrl.isNullOrEmpty()) return null
        val regex = Regex("v=([a-zA-Z0-9_-]+)")
        val matchResult = regex.find(trailerUrl)
        return matchResult?.groups?.get(1)?.value
    }

    // Function to play the trailer
    private fun playTrailer(youtubeId: String) {
        posterImage.visibility = View.GONE
        webViewTrailer.visibility = View.VISIBLE

        val embedUrl = "https://www.youtube.com/embed/$youtubeId"
        webViewTrailer.settings.javaScriptEnabled = true
        webViewTrailer.loadUrl(embedUrl)
    }

    // Function to show poster if trailer not
    private fun showPoster() {
        webViewTrailer.visibility = View.GONE
        posterImage.visibility = View.VISIBLE
    }
}